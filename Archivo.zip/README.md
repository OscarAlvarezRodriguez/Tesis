# Gestor de Tareas - Proyecto experimental

Este repositorio contiene el proyecto base para el experimento académico de la tesis:  
**"Impacto de la inteligencia artificial generativa en la implementación de Test Driven Development"**

## Estructura inicial
```
Este proyecto no requiere dependencias externas. Asegúrate de tener Python 3.x instalado.
```

- `tarea.py`: Clase Tarea con atributos básicos y método para marcar como completada.
- `gestor_tareas.py`: Clase GestorTareas con métodos para agregar, listar y completar tareas.
- `test_tareas.py`: Pruebas unitarias básicas.

## Tu reto
Extiende este proyecto cumpliendo los requisitos indicados en el enunciado del experimento.

## Cómo ejecutar las pruebas
```bash
python -m unittest discover -s tests
```

## Cómo ejecutar el demo opcional (no necesario para el experimento)
```bash
python main.py