@echo off
REM Crear y activar entorno virtual (opcional)
python -m venv venv
call venv\Scripts\activate
echo Entorno virtual activado. Para correr pruebas: python -m unittest test_tareas.py
